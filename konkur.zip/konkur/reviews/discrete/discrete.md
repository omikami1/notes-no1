Table :
season 1 
[season 2](konkur/reviews/discrete/s2)  , [alternative](s2-test)