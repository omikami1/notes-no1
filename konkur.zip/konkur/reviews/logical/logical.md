1. season 1
2. season 2 [s2](konkur/reviews/logical/s2.md)